/** Automatically generated file. DO NOT MODIFY */
package samsung.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}